# Naamsim Folder

This folder contains files related to naamsim in the Cephalon Project.
